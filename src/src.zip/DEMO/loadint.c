#include <stdio.h>
#include <stdlib.h>

#include "../locknload.h"

void main () {
	printf("%d", load(0));
	getchar();
}
